goog.provide('app.events');
re_frame.core.reg_event_db.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword("app.events","initialize-db","app.events/initialize-db",-1317819610),cljs.core.PersistentArrayMap.EMPTY);

//# sourceMappingURL=app.events.js.map
