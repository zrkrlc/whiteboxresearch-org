goog.provide("goog.events.EventLike");
goog.requireType("goog.events.Event");
goog.requireType("goog.events.EventId");
goog.events.EventLike;

//# sourceMappingURL=goog.events.eventlike.js.map
