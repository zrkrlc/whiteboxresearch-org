goog.provide("goog.events.EventWrapper");
goog.requireType("goog.events.EventHandler");
goog.requireType("goog.events.ListenableType");
goog.events.EventWrapper = function() {
};
goog.events.EventWrapper.prototype.listen = function(src, listener, opt_capt, opt_scope, opt_eventHandler) {
};
goog.events.EventWrapper.prototype.unlisten = function(src, listener, opt_capt, opt_scope, opt_eventHandler) {
};

//# sourceMappingURL=goog.events.eventwrapper.js.map
